/**
 * 
 */
package org.oneupfordev.googlepack;

import com.google.api.translate.Translate;

/**
 * @author Roger Leite
 */
public class Tradutor {

	private String de = null;
	private String para = null;
	private String texto = null;

	public Tradutor(String de, String para, String texto) {
		this.de = de;
		this.para = para;
		this.texto = texto;
	}

	public String traduzir() {
		try {
			String traducao = Translate.translate(texto, de, para);
			return traducao;
		} catch (Exception e) {
			return e.getMessage();
		}
	}

}
