/**
 * 
 */
package org.oneupfordev.googlepack;

import org.oneupfordev.doit.ExpressionPack;

/**
 * @author Roger Leite
 */
public class Pack implements ExpressionPack {

	public Class<?>[] getExpressions() {
		return new Class<?>[] {Google.class};
	}

	public String getName() {
		return "googlepack";
	}

}
