/**
 * 
 */
package org.oneupfordev.googlepack;

import org.oneupfordev.doit.CallableExpression;
import org.oneupfordev.doit.packs.annotations.Cmd;
import org.oneupfordev.doit.packs.annotations.Cmds;
import org.oneupfordev.doit.packs.annotations.RootCmd;
import org.oneupfordev.doit.results.Result;
import org.oneupfordev.doit.results.TextResult;
import org.oneupfordev.doit.stuff.DoItSession;

/**
 * @author Roger Leite
 */
@RootCmd(cmds={"traduzir"})
@Cmds({
  @Cmd(name="traduzir", innerCmds={"de"}),
  @Cmd(name="de", innerCmds={"para"})
})
public class Google implements CallableExpression {

	private String assign = null;
	private String de = null;
	private String para = null;

	public Google traduzir() { return this; }
	public Google de(String de) { this.de = de; return this; }
	public Google para(String para) { this.para = para; return this; }

	public Result doIt() {
		String texto = getAssign();  //aqui pegamos o texto após o ":"
		//chama a api do google com os parametros ...
		//String textoTraduzido = ...
		return new TextResult("de: " + de + " para: " + para + " : " + texto);
	}

	public void setAssign(String assign) {
		this.assign = assign;
	}
	public String getAssign() {
		if (assign == null) {
			return "";
		}
		return assign;
	}

	public void setSession(DoItSession session) { }
	public DoItSession getSession() { return null; }

}
