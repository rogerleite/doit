/**
 * 
 */
package org.oneupfordev.gtranslate;

import org.oneupfordev.doit.CallableExpression;
import org.oneupfordev.doit.packs.annotations.RootCmd;
import org.oneupfordev.doit.packs.annotations.RootCmd.Cmd;
import org.oneupfordev.doit.results.Result;
import org.oneupfordev.doit.results.TextResult;
import org.oneupfordev.doit.stuff.Context;

/**
 * @author <a href="roger.leite@1up4dev.org">Roger Leite</a>
 */
@RootCmd(cmds={"from"})
@Cmd(name="from", innerCmds={"to"})
public class Translate implements CallableExpression {

	private String from;
	private String to;
	private String text;

	public Translate(String text) {
		this.text = text;
	}

	public Translate from(String from) {
		this.from = from;
		return this;
	}

	public Translate to(String to) {
		this.to = to;
		return this;
	}

	public Result doIt() {
		StringBuilder result = new StringBuilder("from ").append(from)
								.append(" to ").append(to)
								.append(" text: ").append(text);
		return new TextResult(result.toString());
	}

	public String getAssign() {
		return null;
	}

	public Context getContext() {
		return null;
	}

	public void setAssign(String assign) {
	}

	public void setContext(Context context) {
	}

}
