/**
 * 
 */
package org.oneupfordev.gtranslate;

import org.oneupfordev.doit.ExpressionPack;

/**
 * @author <a href="roger.leite@1up4dev.org">Roger Leite</a>
 */
public class Pack implements ExpressionPack {

	public Class<?>[] getExpressions() {
		return new Class<?>[] {Translate.class};
	}

	public String getName() {
		return "gtranslate";
	}

}
