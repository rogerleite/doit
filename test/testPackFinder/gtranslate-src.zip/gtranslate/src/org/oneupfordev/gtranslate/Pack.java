/**
 * 
 */
package org.oneupfordev.gtranslate;

import java.util.ArrayList;
import java.util.List;

import org.oneupfordev.doit.CallableExpression;
import org.oneupfordev.doit.ExpressionPack;

/**
 * @author <a href="roger.leite@1up4dev.org">Roger Leite</a>
 */
public class Pack implements ExpressionPack {

	public List<Class<? extends CallableExpression>> getExpressions() {
		List<Class<? extends CallableExpression>> list = new ArrayList<Class<? extends CallableExpression>>();
		list.add(Translate.class);
		return list;
	}

	public String getName() {
		return "gtranslate";
	}

}
